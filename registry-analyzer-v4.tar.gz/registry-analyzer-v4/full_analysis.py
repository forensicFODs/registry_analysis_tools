#!/usr/bin/env python3
"""
완전한 Multi-Hive 상세 분석
모든 아티팩트를 생략 없이 출력
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from analyzers.multi_hive_analyzer import MultiHiveAnalyzer

def print_separator(char="=", length=100):
    print(char * length)

def print_section(title):
    print()
    print_separator("=")
    print(f"  {title}")
    print_separator("=")
    print()

def print_subsection(title):
    print()
    print(f"{'─' * 100}")
    print(f"  {title}")
    print(f"{'─' * 100}")
    print()

def main():
    print_separator("=")
    print("  🛡️  Windows Registry Forensic Analyzer v3.1")
    print("  완전한 Multi-Hive 상세 분석 (생략 없음)")
    print_separator("=")
    print()
    
    # Multi-hive Analyzer 생성
    analyzer = MultiHiveAnalyzer()
    
    # 모든 하이브 파일 로드
    hive_files = [
        ('/home/user/uploaded_files/SYSTEM', 'SYSTEM'),
        ('/home/user/uploaded_files/SOFTWARE', 'SOFTWARE'),
        ('/home/user/uploaded_files/NTUSER.DAT', 'NTUSER'),
        ('/home/user/uploaded_files/SAM', 'SAM'),
        ('/home/user/uploaded_files/SECURITY', 'SECURITY'),
        ('/home/user/uploaded_files/UsrClass.dat', 'USRCLASS'),
        ('/home/user/uploaded_files/Amcache.hve', 'AMCACHE'),
    ]
    
    print("📂 하이브 파일 로드 중...")
    loaded = []
    for file_path, hive_type in hive_files:
        if os.path.exists(file_path):
            print(f"   Loading {hive_type}...", end=' ')
            success = analyzer.add_hive(file_path, hive_type)
            if success:
                print("✅")
                loaded.append(hive_type)
            else:
                print("❌")
        else:
            print(f"   {hive_type}: 파일 없음 ⚠️")
    
    print(f"\n✅ {len(loaded)}개 하이브 로드 완료: {', '.join(loaded)}")
    print()
    
    # =================================================================
    # 전체 아티팩트 상세 출력
    # =================================================================
    
    for hive_type, hive_data in analyzer.hives.items():
        print_section(f"📊 {hive_type} 하이브 - 전체 분석 결과")
        
        findings = hive_data.get('findings', {})
        file_path = hive_data.get('file_path', 'N/A')
        
        print(f"파일: {file_path}")
        print()
        
        # 각 아티팩트 타입별로 출력
        for artifact_type, artifacts in findings.items():
            if not artifacts:
                continue
            
            print_subsection(f"{artifact_type.upper()} ({len(artifacts)} items)")
            
            # ShimCache
            if artifact_type == 'shimcache':
                for i, item in enumerate(artifacts, 1):
                    path = item.get('path', 'N/A')
                    ts = item.get('timestamp', 'N/A')
                    size = item.get('fileSize', 0)
                    print(f"{i:4d}. Path: {path}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    if size:
                        print(f"       Size: {size:,} bytes")
                    print()
            
            # Amcache
            elif artifact_type == 'amcache':
                for i, item in enumerate(artifacts, 1):
                    name = item.get('programName', 'N/A')
                    pub = item.get('publisher', 'N/A')
                    ver = item.get('version', 'N/A')
                    sha1 = item.get('sha1', 'N/A')
                    ts = item.get('timestamp', 'N/A')
                    size = item.get('fileSize', 0)
                    print(f"{i:4d}. Program: {name}")
                    if pub != 'N/A':
                        print(f"       Publisher: {pub}")
                    if ver != 'N/A':
                        print(f"       Version: {ver}")
                    if sha1 != 'N/A':
                        print(f"       SHA1: {sha1}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    if size:
                        print(f"       Size: {size:,} bytes")
                    print()
            
            # UserAssist
            elif artifact_type == 'userassist':
                for i, item in enumerate(artifacts, 1):
                    prog = item.get('program', 'N/A')
                    count = item.get('runCount', 0)
                    ts = item.get('lastExecuted', 'N/A')
                    print(f"{i:4d}. Program: {prog}")
                    if count:
                        print(f"       Run Count: {count}")
                    if ts != 'N/A':
                        print(f"       Last Executed: {ts}")
                    print()
            
            # BAM/DAM
            elif artifact_type == 'bam_dam':
                for i, item in enumerate(artifacts, 1):
                    path = item.get('path', 'N/A')
                    ts = item.get('timestamp', 'N/A')
                    print(f"{i:4d}. Path: {path}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    print()
            
            # USB Devices
            elif artifact_type == 'usb_devices':
                for i, item in enumerate(artifacts, 1):
                    serial = item.get('serialNumber', 'N/A')
                    vendor = item.get('vendorId', 'N/A')
                    product = item.get('productId', 'N/A')
                    drive = item.get('driveLetter', 'N/A')
                    ts = item.get('lastConnected', 'N/A')
                    print(f"{i:4d}. Serial: {serial}")
                    if vendor != 'N/A':
                        print(f"       Vendor ID: {vendor}")
                    if product != 'N/A':
                        print(f"       Product ID: {product}")
                    if drive != 'N/A':
                        print(f"       Drive Letter: {drive}")
                    if ts != 'N/A':
                        print(f"       Last Connected: {ts}")
                    print()
            
            # Recent Docs
            elif artifact_type == 'recent_docs':
                for i, item in enumerate(artifacts, 1):
                    path = item.get('path', 'N/A')
                    ts = item.get('timestamp', 'N/A')
                    print(f"{i:4d}. Path: {path}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    print()
            
            # Run Keys
            elif artifact_type == 'run_keys':
                for i, item in enumerate(artifacts, 1):
                    prog = item.get('program', 'N/A')
                    path = item.get('path', 'N/A')
                    location = item.get('location', 'N/A')
                    print(f"{i:4d}. Program: {prog}")
                    if path != 'N/A':
                        print(f"       Path: {path}")
                    if location != 'N/A':
                        print(f"       Location: {location}")
                    print()
            
            # SAM Users
            elif artifact_type == 'sam_users':
                for i, item in enumerate(artifacts, 1):
                    user = item.get('username', 'N/A')
                    sid = item.get('sid', 'N/A')
                    ts = item.get('lastLogin', 'N/A')
                    print(f"{i:4d}. Username: {user}")
                    if sid != 'N/A':
                        print(f"       SID: {sid}")
                    if ts != 'N/A':
                        print(f"       Last Login: {ts}")
                    print()
            
            # Network Profiles
            elif artifact_type == 'network_profiles':
                for i, item in enumerate(artifacts, 1):
                    name = item.get('profileName', 'N/A')
                    ts = item.get('timestamp', 'N/A')
                    print(f"{i:4d}. Profile: {name}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    print()
            
            # ShellBags
            elif artifact_type == 'shellbags':
                for i, item in enumerate(artifacts, 1):
                    path = item.get('path', 'N/A')
                    ts = item.get('timestamp', 'N/A')
                    print(f"{i:4d}. Path: {path}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    print()
            
            # MuiCache
            elif artifact_type == 'muicache':
                for i, item in enumerate(artifacts, 1):
                    path = item.get('path', 'N/A')
                    app = item.get('appName', 'N/A')
                    ts = item.get('timestamp', 'N/A')
                    print(f"{i:4d}. Path: {path}")
                    if app != 'N/A':
                        print(f"       App Name: {app}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    print()
            
            # Prefetch
            elif artifact_type == 'prefetch':
                for i, item in enumerate(artifacts, 1):
                    prog = item.get('program', 'N/A')
                    count = item.get('runCount', 0)
                    ts = item.get('timestamp', 'N/A')
                    print(f"{i:4d}. Program: {prog}")
                    if count:
                        print(f"       Run Count: {count}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    print()
            
            # LNK Files
            elif artifact_type == 'lnk_files':
                for i, item in enumerate(artifacts, 1):
                    lnk = item.get('lnkPath', 'N/A')
                    target = item.get('targetPath', 'N/A')
                    ts = item.get('timestamp', 'N/A')
                    print(f"{i:4d}. LNK: {lnk}")
                    if target != 'N/A':
                        print(f"       Target: {target}")
                    if ts != 'N/A':
                        print(f"       Timestamp: {ts}")
                    print()
            
            # Installed Software
            elif artifact_type == 'installed_software':
                for i, item in enumerate(artifacts, 1):
                    name = item.get('displayName', 'N/A')
                    pub = item.get('publisher', 'N/A')
                    ver = item.get('version', 'N/A')
                    date = item.get('installDate', 'N/A')
                    loc = item.get('installLocation', 'N/A')
                    print(f"{i:4d}. Software: {name}")
                    if pub != 'N/A':
                        print(f"       Publisher: {pub}")
                    if ver != 'N/A':
                        print(f"       Version: {ver}")
                    if date != 'N/A':
                        print(f"       Install Date: {date}")
                    if loc != 'N/A':
                        print(f"       Location: {loc}")
                    print()
            
            # Security Detailed
            elif artifact_type == 'security_detailed':
                for i, item in enumerate(artifacts, 1):
                    item_type = item.get('type', 'N/A')
                    if item_type == 'SecurityPolicy':
                        key = item.get('policyKey', 'N/A')
                        name = item.get('policyName', 'N/A')
                        val = item.get('value', 'N/A')
                        print(f"{i:4d}. Policy: {name}")
                        if key != 'N/A':
                            print(f"       Key: {key}")
                        if val != 'N/A':
                            print(f"       Value: {val}")
                    elif item_type == 'SID':
                        sid = item.get('sid', 'N/A')
                        sid_type = item.get('sidType', 'N/A')
                        print(f"{i:4d}. SID: {sid}")
                        if sid_type != 'N/A':
                            print(f"       Type: {sid_type}")
                    print()
            
            # TypedPaths (v3.1)
            elif artifact_type == 'typed_paths':
                for i, item in enumerate(artifacts, 1):
                    path = item.get('path', 'N/A')
                    mru = item.get('mruOrder')
                    print(f"{i:4d}. Path: {path}")
                    if mru is not None:
                        print(f"       MRU Order: {mru}")
                    print()
            
            # RecentApps (v3.1)
            elif artifact_type == 'recent_apps':
                for i, item in enumerate(artifacts, 1):
                    app = item.get('appName', 'N/A')
                    path = item.get('appPath', 'N/A')
                    count = item.get('launchCount', 0)
                    ts = item.get('lastAccessTime', 'N/A')
                    print(f"{i:4d}. App: {app}")
                    if path != 'N/A':
                        print(f"       Path: {path}")
                    if count:
                        print(f"       Launch Count: {count}")
                    if ts != 'N/A':
                        print(f"       Last Access: {ts}")
                    print()
            
            # Services (v3.1)
            elif artifact_type == 'services_detailed':
                for i, item in enumerate(artifacts, 1):
                    name = item.get('serviceName', 'N/A')
                    display = item.get('displayName', 'N/A')
                    path = item.get('imagePath', 'N/A')
                    start = item.get('startType', 'N/A')
                    print(f"{i:4d}. Service: {name}")
                    if display != 'N/A' and display != name:
                        print(f"       Display: {display}")
                    if start != 'N/A':
                        print(f"       Start Type: {start}")
                    if path != 'N/A':
                        print(f"       Image Path: {path}")
                    print()
            
            # WLAN (v3.1)
            elif artifact_type == 'wlan_profiles':
                for i, item in enumerate(artifacts, 1):
                    name = item.get('profileName', 'N/A')
                    conn = item.get('connectionType', 'N/A')
                    ts = item.get('lastConnectedTime', 'N/A')
                    print(f"{i:4d}. Profile: {name}")
                    if conn != 'N/A':
                        print(f"       Connection Type: {conn}")
                    if ts != 'N/A':
                        print(f"       Last Connected: {ts}")
                    print()
            
            # TimeZone (v3.1)
            elif artifact_type == 'timezone':
                for i, item in enumerate(artifacts, 1):
                    std = item.get('standardName', 'N/A')
                    day = item.get('daylightName', 'N/A')
                    bias = item.get('bias')
                    print(f"{i:4d}. Standard: {std}")
                    if day != 'N/A':
                        print(f"       Daylight: {day}")
                    if bias is not None:
                        hours = -(bias // 60)
                        print(f"       UTC Offset: {hours:+d}:00")
                    print()
    
    # =================================================================
    # 상관관계 분석
    # =================================================================
    
    print_section("🔗 Cross-Hive 상관관계 분석")
    
    correlations = analyzer.find_correlations()
    
    if correlations:
        for i, corr in enumerate(correlations, 1):
            corr_type = corr.get('type', 'Unknown')
            confidence = corr.get('confidence', 'UNKNOWN')
            significance = corr.get('significance', '')
            
            conf_emoji = {'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '🟢'}.get(confidence, '⚪')
            
            print(f"{i:3d}. {conf_emoji} [{confidence}] {corr_type}")
            print(f"     {significance}")
            print()
    else:
        print("상관관계를 발견하지 못했습니다.")
    
    # =================================================================
    # 통합 타임라인
    # =================================================================
    
    print_section("📅 통합 타임라인 (전체)")
    
    timeline = analyzer.build_timeline()
    
    if timeline:
        # 시간순 정렬 (문자열로 안전하게)
        sorted_timeline = sorted(timeline, key=lambda x: str(x.get('timestamp', '')))
        
        for i, event in enumerate(sorted_timeline, 1):
            ts = event.get('timestamp', 'N/A')
            desc = event.get('description', 'Unknown')
            hive = event.get('hive', 'N/A')
            artifact = event.get('artifact_type', 'N/A')
            
            print(f"{i:4d}. [{ts}] {desc}")
            print(f"       Source: {hive} - {artifact}")
            print()
    
    # =================================================================
    # 요약
    # =================================================================
    
    print_section("📊 분석 요약")
    
    summary = analyzer.get_summary()
    
    print(f"Loaded Hives: {summary['hive_count']}")
    print(f"Total Artifacts Found: {summary['total_artifacts']}")
    print(f"Correlations: {summary['correlation_count']}")
    print(f"  └─ High Confidence: {summary['high_confidence_correlations']}")
    print(f"Timeline Events: {summary['timeline_events']}")
    print()
    
    print_separator("=")
    print("✅ 전체 분석 완료!")
    print_separator("=")

if __name__ == '__main__':
    main()

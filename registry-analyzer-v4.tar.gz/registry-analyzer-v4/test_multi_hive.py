#!/usr/bin/env python3
"""
Multi-Hive Analyzer 테스트
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from analyzers.multi_hive_analyzer import MultiHiveAnalyzer

def test_multi_hive():
    """Multi-hive analyzer 기본 기능 테스트"""
    
    print("=" * 80)
    print("Multi-Hive Analyzer 테스트")
    print("=" * 80)
    print()
    
    analyzer = MultiHiveAnalyzer()
    
    # SAM 파일 추가 테스트
    test_file = '../public/samples/SAM'
    
    if os.path.exists(test_file):
        print(f"📂 테스트 파일: {test_file}")
        success = analyzer.add_hive(test_file, 'SAM')
        
        if success:
            print("✅ Hive 로드 성공")
            
            # 요약 정보
            summary = analyzer.get_summary()
            print(f"\n📊 Summary:")
            print(f"   - Loaded hives: {summary['loaded_hives']}")
            print(f"   - Hive count: {summary['hive_count']}")
            print(f"   - Total artifacts: {summary['total_artifacts']}")
            
            # 상관관계 분석
            print(f"\n🔍 Finding correlations...")
            correlations = analyzer.find_correlations()
            print(f"   - Found {len(correlations)} correlations")
            
            # 타임라인 생성
            print(f"\n📅 Building timeline...")
            timeline = analyzer.build_timeline()
            print(f"   - Timeline events: {len(timeline)}")
            
            if timeline:
                print(f"\n   Recent events (최대 3개):")
                for i, event in enumerate(timeline[:3], 1):
                    print(f"      {i}. [{event['timestamp']}] {event['description']}")
            
            print("\n✅ Multi-Hive Analyzer 정상 작동!")
        else:
            print("❌ Hive 로드 실패")
    else:
        print(f"❌ 테스트 파일 없음: {test_file}")
    
    print("\n" + "=" * 80)
    print("테스트 완료")
    print("=" * 80)

if __name__ == '__main__':
    test_multi_hive()

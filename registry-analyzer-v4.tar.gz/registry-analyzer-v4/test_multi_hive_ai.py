#!/usr/bin/env python3
"""
Multi-Hive AI 분석 통합 테스트
AI 분석이 Multi-Hive 결과에 추가되는지 검증
"""

import sys
import os

# 모듈 경로 추가
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from analyzers.multi_hive_analyzer import MultiHiveAnalyzer
from analyzers.ai_analyzer import AIAnalyzer

def test_multi_hive_ai_integration():
    """Multi-Hive + AI 통합 테스트"""
    print("\n" + "="*80)
    print("Multi-Hive AI Integration Test")
    print("="*80 + "\n")
    
    # 1. 테스트 파일 경로
    test_files = [
        ('/home/user/uploaded_files/SYSTEM', 'SYSTEM'),
        ('/home/user/uploaded_files/SOFTWARE', 'SOFTWARE'),
        ('/home/user/uploaded_files/Amcache.hve', 'Amcache.hve')
    ]
    
    # 존재하는 파일 확인
    available_files = []
    for path, hive_type in test_files:
        if os.path.exists(path):
            available_files.append((path, hive_type))
            print(f"✅ Found: {hive_type}")
        else:
            print(f"⚠️  Missing: {hive_type}")
    
    if len(available_files) < 2:
        print("\n❌ Multi-Hive 분석을 위해 최소 2개 이상의 파일이 필요합니다.")
        return False
    
    print(f"\n📚 Total files: {len(available_files)}")
    
    # 2. Multi-Hive 분석
    print("\n" + "-"*80)
    print("Starting Multi-Hive Analysis...")
    print("-"*80 + "\n")
    
    analyzer = MultiHiveAnalyzer()
    
    for path, hive_type in available_files:
        try:
            analyzer.add_hive(path, hive_type)
            print(f"✅ Loaded: {hive_type}")
        except Exception as e:
            print(f"❌ Failed: {hive_type} - {e}")
    
    # 3. 상관관계 & 타임라인
    print("\n🔍 Finding correlations...")
    correlations = analyzer.find_correlations()
    print(f"✅ {len(correlations)} correlations found")
    
    print("\n📅 Building timeline...")
    timeline = analyzer.build_timeline()
    print(f"✅ {len(timeline)} events in timeline")
    
    summary = analyzer.get_summary()
    
    # 4. Multi-Hive 데이터 수집 (AI 전송용)
    print("\n" + "-"*80)
    print("Preparing data for AI analysis...")
    print("-"*80 + "\n")
    
    all_findings = {}
    all_strings = []
    
    for hive_type, hive_data in analyzer.hives.items():
        findings = hive_data.get('findings', {})
        for artifact_type, artifacts in findings.items():
            if artifact_type not in all_findings:
                all_findings[artifact_type] = []
            all_findings[artifact_type].extend(artifacts)
        
        if hive_data.get('parser'):
            strings = hive_data['parser'].extract_strings()[:200]
            all_strings.extend(strings)
    
    print(f"✅ Collected {len(all_strings)} strings")
    print(f"✅ Collected {len(all_findings)} artifact types")
    for artifact_type, artifacts in all_findings.items():
        print(f"   - {artifact_type}: {len(artifacts)} items")
    
    # 5. AI 분석 데이터 준비
    ai_input_data = {
        'summary': summary,
        'correlations': correlations[:20],  # 상위 20개
        'timeline': timeline[:50],  # 최근 50개
        'artifact_counts': {k: len(v) for k, v in all_findings.items()}
    }
    
    print("\n" + "-"*80)
    print("AI Input Data Summary:")
    print("-"*80)
    print(f"  - Hives: {summary['hive_count']}")
    print(f"  - Total Artifacts: {summary['total_artifacts']}")
    print(f"  - Correlations: {len(ai_input_data['correlations'])}")
    print(f"  - Timeline Events: {len(ai_input_data['timeline'])}")
    print(f"  - String Samples: {len(all_strings[:1000])}")
    
    # 6. 검증
    print("\n" + "="*80)
    print("VERIFICATION RESULTS")
    print("="*80 + "\n")
    
    checks = {
        "Multi-Hive analyzer created": analyzer is not None,
        "At least 2 hives loaded": len(analyzer.hives) >= 2,
        "Correlations found": len(correlations) > 0,
        "Timeline built": len(timeline) > 0,
        "Summary generated": summary is not None,
        "AI input data prepared": ai_input_data is not None,
        "Strings collected": len(all_strings) > 0,
        "Artifact types found": len(all_findings) > 0
    }
    
    all_passed = True
    for check_name, result in checks.items():
        status = "✅" if result else "❌"
        print(f"{status} {check_name}")
        if not result:
            all_passed = False
    
    print("\n" + "="*80)
    if all_passed:
        print("✅ TEST PASSED - Multi-Hive AI 통합 준비 완료!")
        print("\n💡 AI 분석 사용 방법:")
        print("   1. GUI에서 'Multi-Hive Analysis' 버튼 클릭")
        print("   2. API Key를 미리 입력해두기 (Gemini 또는 OpenAI)")
        print("   3. 2개 이상의 레지스트리 파일 선택")
        print("   4. 분석 시작 → AI 분석 자동 실행")
        print("\n📊 AI 분석 결과 섹션:")
        print("   - 📊 Summary: 전체 분석 요약")
        print("   - ⚠️  Suspicious Activities: 의심스러운 활동")
        print("   - ⏱️  Timeline: AI 생성 타임라인")
        print("   - 💡 Recommendations: 보안 권장사항")
    else:
        print("❌ TEST FAILED - 일부 검증 실패")
    print("="*80 + "\n")
    
    return all_passed


if __name__ == '__main__':
    success = test_multi_hive_ai_integration()
    sys.exit(0 if success else 1)

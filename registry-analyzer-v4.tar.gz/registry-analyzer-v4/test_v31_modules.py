#!/usr/bin/env python3
"""
v3.1 새 모듈 통합 테스트
5개 새 분석 모듈이 제대로 작동하는지 확인
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from core.registry_parser import RegistryParser
from analyzers.forensics_analyzer import ForensicsAnalyzer

def test_new_modules():
    """5개 새 모듈 테스트"""
    
    print("=" * 80)
    print("Windows Registry Forensic Analyzer v3.1 - 새 모듈 테스트")
    print("=" * 80)
    print()
    
    # 테스트 파일
    test_file = './public/samples/SAM'
    if not os.path.exists(test_file):
        print(f"❌ 테스트 파일 없음: {test_file}")
        return
    
    print(f"📂 테스트 파일: {test_file}")
    print()
    
    try:
        # Parser 생성
        parser = RegistryParser(test_file)
        analyzer = ForensicsAnalyzer(parser, 'SAM')
        
        # 5개 새 모듈 테스트
        new_modules = [
            ('typed_paths', 'TypedPaths (Explorer Address Bar)'),
            ('recent_apps', 'RecentApps (Windows 10+ Recent Apps)'),
            ('services_detailed', 'Services (System Services Detailed)'),
            ('wlan_profiles', 'WLAN Profiles (Wi-Fi Networks)'),
            ('timezone', 'Time Zone Information')
        ]
        
        print("🧪 5개 새 모듈 실행 테스트:")
        print("-" * 80)
        
        results = {}
        for module_name, description in new_modules:
            method = getattr(analyzer, f'analyze_{module_name}')
            data = method()
            results[module_name] = data
            
            status = "✅" if isinstance(data, list) else "❌"
            count = len(data) if isinstance(data, list) else "ERROR"
            print(f"{status} {description}: {count} items")
        
        print()
        print("=" * 80)
        print("📊 상세 결과:")
        print("=" * 80)
        print()
        
        # TypedPaths
        if results['typed_paths']:
            print(f"📍 TypedPaths: {len(results['typed_paths'])} items")
            for i, item in enumerate(results['typed_paths'][:3], 1):
                mru = f" [MRU:{item.get('mruOrder')}]" if item.get('mruOrder') is not None else ""
                print(f"   {i}. {item['path']}{mru}")
            if len(results['typed_paths']) > 3:
                print(f"   ... ({len(results['typed_paths']) - 3} more)")
            print()
        
        # RecentApps
        if results['recent_apps']:
            print(f"📱 RecentApps: {len(results['recent_apps'])} items")
            for i, item in enumerate(results['recent_apps'][:3], 1):
                count = f" (Launches: {item.get('launchCount')})" if item.get('launchCount') else ""
                print(f"   {i}. {item.get('appName', 'Unknown')}{count}")
            if len(results['recent_apps']) > 3:
                print(f"   ... ({len(results['recent_apps']) - 3} more)")
            print()
        
        # Services
        if results['services_detailed']:
            print(f"⚙️  Services: {len(results['services_detailed'])} items")
            for i, item in enumerate(results['services_detailed'][:3], 1):
                start = item.get('startType', 'Unknown')
                print(f"   {i}. {item.get('serviceName', 'Unknown')} [{start}]")
                print(f"       {item.get('imagePath', 'N/A')}")
            if len(results['services_detailed']) > 3:
                print(f"   ... ({len(results['services_detailed']) - 3} more)")
            print()
        
        # WLAN
        if results['wlan_profiles']:
            print(f"📶 WLAN Profiles: {len(results['wlan_profiles'])} items")
            for i, item in enumerate(results['wlan_profiles'][:3], 1):
                conn = item.get('connectionType', 'Unknown')
                print(f"   {i}. {item.get('profileName', 'Unknown')} ({conn})")
            if len(results['wlan_profiles']) > 3:
                print(f"   ... ({len(results['wlan_profiles']) - 3} more)")
            print()
        
        # TimeZone
        if results['timezone']:
            print(f"🌍 Time Zone: {len(results['timezone'])} items")
            for i, item in enumerate(results['timezone'][:3], 1):
                std = item.get('standardName', 'Unknown')
                bias = item.get('bias')
                bias_str = ""
                if bias is not None:
                    hours = -(bias // 60)
                    bias_str = f" (UTC{hours:+d}:00)"
                print(f"   {i}. {std}{bias_str}")
            print()
        
        print("=" * 80)
        print("✅ 모든 모듈이 정상적으로 작동합니다!")
        print("=" * 80)
        
    except Exception as e:
        print(f"❌ 테스트 실패: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    test_new_modules()
